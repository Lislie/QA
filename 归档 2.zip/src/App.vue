<style lang="stylus" rel="stylesheet/stylus">
html, body {
  background-color: black;
  width: 100%;
  // height auto
  overflow: auto;
}

// .el-container
// height 100%
.el-header, .el-footer {
  margin: 0 15%;
  // background-color black
  // width 6.25rem
  color: #fff;
  // text-align c
  min-width: 1024px;
  // height 84px
  display: flex;
  justify-content: space-between;

  #h-left {
    display: flex;
    height: 100%;
    text-align: center;
    justify-content: center;
    align-items: center;

    span {
      width: 75px;
      height: 36px;
      background: url('./assets/e.png') no-repeat no-repeat;
      background-size: 100%;
      margin-right: 15px;

      #title {
        display: flex;
        // float left
        flex-direction: column;
      }
    }

    .t1 {
      font-size: 20px;
      padding-bottom: 10px;
    }

    p {
      font-size: 10px;
    }
  }

  #h-right {
    display: flex;
    height: 100%;
    text-align: center;
    justify-content: center;
    align-items: center;

    p {
      margin-right: 37px;
    }

    #dh {
      width: 16px;
      height: 16px;
      background: url('./assets/phone.png') no-repeat no-repeat;
      background-size: 100%;
      margin-right: 8px;
    }

    #bz {
      width: 24px;
      height: 24px;
      background: url('./assets/bz.png') no-repeat no-repeat;
      background-size: 100%;
      margin-left: 22px;
    }

    .el-submenu__title {
      display: flex;
      text-align: center;
      justify-content: center;
      align-items: center;

      p {
        text-align: center;
        display: flex;
        text-align: center;
        justify-content: center;
        align-items: center;
      }
    }
  }
}

.el-footer {
  height: 320px;
  display: flex;
  flex-direction: column;
  font-size: 14px;
  text-align: center;
  justify-content: center;
  align-items: center;

  #f-top {
    display: flex;
    justify-content: space-around;
    margin-bottom: 30px;

    p {
      margin-right: 50px;
    }
  }
}

.el-main {
  padding: 0;
  background-color: #fff;
  min-height: 800px;
}
</style>

<template>
  <el-container>
  <toast id="toast" v-show="toastShow" style="z-index:999;top:200px"></toast>
  <el-header style="height:108px">
    <div id='h-left'>
      <span></span>
      <div id="title">
        <h1 class="t1">逸途-旅游问答社区</h1>
        <p>EASYTO TOURISM KNOWLEDGE</p>
      </div>
    </div>
    <div id="h-right">
      <span id="dh"></span>
      <p>400-826-1977</p>
      <el-menu
        :default-active="activeIndex2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="black"
        text-color="#fff"
        active-text-color="#fff" v-if="Login">
        <el-submenu index="1">
          <template slot="title" id="ti">
            <span></span>
            <p>UserName</p>
          </template>
          <el-menu-item index="1-1">
            <router-link  class="tab-item" to="/myQuestion">
              <span>我的问答</span>
            </router-link>
          </el-menu-item>
          <el-menu-item index="1-2">
            <router-link  class="tab-item" to="/myEarnings">
              <span>我的收益</span>
            </router-link></el-menu-item>
          <el-menu-item index="1-3">
            <router-link  class="tab-item" to="/feedBack">
              <span>意见反馈</span>
            </router-link></el-menu-item>
          </el-menu-item>
          <el-menu-item index="1-4">
            <router-link  class="tab-item" to="/account">
              <span>账户安全</span>
            </router-link></el-menu-item>
          </el-menu-item>
          <el-menu-item index="1-5" @click="exit">
            <router-link  class="tab-item" to="/">
              <span>退出</span>
            </router-link></el-menu-item>
          </el-menu-item>
        </el-submenu>
      </el-menu>
      <div v-else>
        <router-link  to="/Login">
          <span style="color:#fff">登录</span>
        </router-link>
        <span>|</span>
        <router-link  to="/register">
           <span style="color:#fff">注册</span>
        </router-link>
      </div>
      <span id='bz'></span>
    </div>
  </el-header>
  <el-main>
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </el-main>
  <el-footer style="height:220px">
    <div id="f-top">
      <p>北京市朝阳区酒仙桥路4号海航大厦</p>
      <p>Tel:(021) 3232-3902</p>
      <p>Fax:(021）54261600</p>
      <p>ZipCode: 200335</p>
    </div>
    <p>Copyright 2016-2019 easyto.com 京ICP备 15037968</p>
  </el-footer>
 </el-container>
</template>

<script>
import toast from './components/toast/toast'
export default {
  components: { toast },
  data() {
    return {
      Login: false,
      activeIndex: '1',
      activeIndex2: '1',
      toastShow: false,
    }
  },
  watch: {
    $route: {
      handler(curVal, oldVal) {
        // console.log(curVal)
        if (curVal.query.id == 1) {
          this.Login = true
        }
      },
      deep: true
    }
  },
  created() {
    this.loginQue()
  },
  methods: {
    handleSelect(key, keyPath) {
      // console.log(key, keyPath)
    },
    loginQue() {
      if (localStorage.getItem("login") == "true") {
        this.Login = true
      } else {
        this.Login = false
      }
    },

    // 退出登录========================================================
    exit() {
      // 调接口----------------
      var _this = this;
      this.$indexServer.exit()
        .then((res) => {
          if (res.data.code == 200) {
            _this.$router.push('/')
            _this.Login = false
            localStorage.clear()
          } else if (res.data.code == 4010) {
            _this.enterToast('登录已过期，请重新登录')
          } else if (res.data.code == 4006) {
            _this.enterToast('该用户账号不存在')
          } else {
            _this.enterToast('服务异常，请稍后再试')
          }
        })
    },
    enterToast(text, time) {
      var toast = document.getElementById("toast");
      // console.log(toast)
      if (toast) {
        toast.innerHTML = text;
        this.toastShow = true;
        setTimeout(() => {
          this.toastShow = false;
        }, 2000 || time);
      }
    }

  },

}
</script>
