<template>
    <div class="toast">
          
    </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  methods: {
   
  }
}
</script>
<style lang="stylus" rel="stylesheet/stylus">
.toast{ 
    display flex
    align-items center
    justify-content center
    position fixed
    margin auto
    top 340px
    left 0
    right 0
    // bottom 0
    padding 20px 20px
    max-width 250px
    background-color rgba(0,0,0,0.4) 
    font-size 14px
    color #fff
    border-radius 5px   
}
</style>
