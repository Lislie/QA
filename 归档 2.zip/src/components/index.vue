<style scoped lang="stylus" rel="stylesheet/stylus">
.content {
  width: 100%;
  height: 100%;
  min-width: 1024px;
  color: #fff;
  font-family: 'STYuanti-SC-Regular';
}

.index1 {
  height: 100%;
  width: 100%;
  // min-height 60px
  background: url('../assets/banner.png') no-repeat no-repeat;
  overflow: hidden;

  .title1 {
    text-align: center;
    padding-top: 70px;

    h2 {
      font-size: 50px;
      // padding-bottom 32px
    }

    .tp1 {
      padding-bottom: 24px;
      font-size: 36px;
    }

    .tp2 {
      padding-bottom: 93px;
      font-size: 22px;
    }

    .s1 {
      font-size: 36px;
      color: #f1c224;
      margin: 0 15px;
      text-align: center;
    }

    img {
      // padding-top 10px
      position: relative;
      top: 20px;
    }
  }

  .cont1 {
    text-align: center;
    display: flex;
    justify-content: center;
    padding-bottom: 87px;
    overflow: hidden;

    li {
      display: flex;
      // text-align center
      margin-right: 62px;

      span {
        width: 66px;
        height: 66px;
        display: inline-block;
        margin-right: 21px;
      }

      p {
        font-size: 34px;
      }

      .p2 {
        padding-top: 15px;
        font-size: 18px;
      }

      .sp1 {
        background: url('../assets/dz.png') no-repeat no-repeat;
        background-size: 100%;
      }

      .sp2 {
        background: url('../assets/cy.png') no-repeat no-repeat;
        background-size: 100%;
      }

      .sp3 {
        background: url('../assets/wt.png') no-repeat no-repeat;
        background-size: 100%;
      }

      .sp4 {
        background: url('../assets/ls.png') no-repeat no-repeat;
        background-size: 100%;
      }
    }
  }

  .btn1 {
    text-align: center;
    margin: 0 auto;
    display: flex;
    width: 288px;
    height: 69px;
    background-color: red;
    margin-bottom: 86px;
    // overflow hidden
    color: #fefefe;
    font-size: 30px;
    font-family: 'PingFangSC-Regular';
    justify-content: center;
  }
}

.index2 {
  width: 100%;
  height: 870px;
  background-color: #fff;

  h2 {
    font-size: 36px;
    color: black;
    text-align: center;
    padding: 108px 0 103px 0;
    // position relative
  }

  .line {
    height: 13px;
    width: 1200px;
    background: url('../assets/jx.png') no-repeat;
    text-align: center;
    margin: 0 auto;
    position: relative;
    overflow: hidden;
    top: -125px;
  }

  .benner {
    width: 100%;
    height: 400px;
    background-color: #dedede;
    // margin-top 62px
  }

  ul {
    display: flex;
    // text-align center
    margin: 0 auto;
    justify-content: center;
    position: relative;
    top: -450px;

    li {
      width: 348px;
      height: 501px;
      background-color: red;
      margin: 0 40px;
    }

    .l1 {
      background: url('../assets/zx.png') no-repeat;
      background-size: 100%;

      p {
        width: 100%;
        height: 60px;
        background-color: rgba(1, 0, 25, 0.78);
        text-align: center;
        line-height: 60px;
        font-size: 24px;
        position: relative;
        top: 380px;
      }
    }

    .l3 {
      background: url('../assets/lx.png') no-repeat;
      background-size: 100%;

      p {
        width: 100%;
        height: 60px;
        background-color: rgba(1, 0, 25, 0.78);
        text-align: center;
        line-height: 60px;
        font-size: 24px;
        position: relative;
        top: 380px;
      }
    }

    .l2 {
      background: url('../assets/img2.png') no-repeat;

      // background-size 150%
      .l2_cont {
        margin: 105px 60px;

        h3 {
          font-size: 24px;
          margin-bottom: 50px;
        }

        p {
          font-size: 16px;
          margin-bottom: 40px;
          line-height: 30px;
        }
      }
    }
  }
}

.index3 {
  // display flex
  width: 100%;
  height: 729px;
  background: url('../assets/banner2.png') no-repeat;
  // background-size 100%
  overflow: hidden;
  color: #fff;

  // flex-direction column
  // text-align center
  h2 {
    font-size: 36px;
    text-align: center;
    margin: 108px 0 72px 0;
    // position relative
  }

  .line {
    height: 13px;
    width: 1200px;
    background: url('../assets/line2.png') no-repeat;
    text-align: center;
    margin: 0 auto;
    position: relative;
    overflow: hidden;
    top: -100px;
  }

  ul {
    display: flex;
    // text-align center
    margin: 0 auto;
    justify-content: center;

    li {
      width: 381px;
      height: 444px;
      border: 1px solid;
      margin: 0 75px;
      display: flex;
      flex-direction: column;
      text-align: center;
    }

    .l1 {
      span {
        display: block;
        width: 66px;
        height: 70px;
        background: url('../assets/sy.png') no-repeat;
        margin: 31px auto 18px;
      }

      h3 {
        font-size: 24px;
        margin-bottom: 68px;
      }

      p {
        font-size: 16px;
        margin: 0 25px 50px;
      }
    }

    .l2 {
      height: 351px;

      span {
        display: block;
        width: 66px;
        height: 70px;
        background: url('../assets/rw.png') no-repeat;
        margin: 31px auto 18px;
      }

      h3 {
        font-size: 24px;
        margin-bottom: 68px;
      }

      p {
        font-size: 16px;
        margin: 0 25px 50px;
      }
    }
  }
}

.index4 {
  // display flex
  width: 100%;
  height: 787px;
  overflow: hidden;
  color: black;
  background-color: #fff;

  // flex-direction column
  // text-align center
  h2 {
    font-size: 36px;
    text-align: center;
    margin: 108px 0 50px 0;
    // position relative
  }

  .line4 {
    height: 13px;
    width: 1200px;
    background: url('../assets/line3.png') no-repeat;
    text-align: center;
    margin: 0 auto;
    position: relative;
    overflow: hidden;
    top: -70px;
  }

  ul {
    display: flex;
    // margin: 0 auto;
    justify-content: center;
    height: 300p;

    .cent4 {
      width: 150px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    li {
      width: 200px;
      margin: 0 25px;
      font-size: 18px;
      position: relative;

      span {
        width: 78px;
        height: 78px;
        display: block;
        font-size: 30px;
        margin: 0 auto 45px;
      }

      p {
        line-height: 26px;
      }

      .sp {
        width: 12px;
        height: 22px;
        background: url('../assets/jt.png') no-repeat;
        background-size: 100%;
        float: right;
        position: absolute;
        top: 75px;
        right: 0;
      }

      .sp1 {
        background: url('../assets/zc2.png') no-repeat;
        background-size: 100%;
      }

      .sp2 {
        background: url('../assets/dj.png') no-repeat;
        background-size: 100%;
      }

      .sp3 {
        background: url('../assets/hd.png') no-repeat;
        background-size: 100%;
      }

      .sp4 {
        background: url('../assets/dd.png') no-repeat;
        background-size: 100%;
      }

      .sp5 {
        background: url('../assets/sy2.png') no-repeat;
        background-size: 100%;
      }
    }
  }

  .btn2 {
    text-align: center;
    margin: 122px auto;
    display: flex;
    width: 288px;
    height: 69px;
    background-color: red;
    margin-bottom: 86px;
    // overflow hidden
    color: #fefefe;
    font-size: 30px;
    font-family: 'PingFangSC-Regular';
    justify-content: center;
  }
}
</style>
<template>
  <div class="content">
    <div class="index1">
        <div class="title1">
          <h2>旅游问答回享计划</h2>
          <p class="tp1">回答旅游问题即可获得<span class="s1">现金<img src="../assets/baibaoixnagjizi.png" alt=""></span>收益</p>
          <p class="tp2">你的每一个问答都有可能帮助到无数出游者</p>
        </div>
        <ul class="cont1">
          <li>
            <span class="sp1"></span>
            <div>
              <p>¥68674.80</p>
              <p class="p2">答主回享总额</p>
            </div>
          </li>
          <li>
            <span class="sp2"></span>
            <div>
              <p>267</p>
              <p class="p2">参与答主</p>
            </div>
          </li>
          <li>
            <span class="sp3"></span>
            <div>
              <p>12878</p>
              <p class="p2">已回答问题</p>
            </div>
          </li>
          <li>
            <span class="sp4"></span>
            <div>
              <p>82768</p>
              <p class="p2">历史帮助游客</p>
            </div>

          </li>
        </ul>
        <button class="btn1" @click="myQuen">立即答题</button>
    </div>
    <div class="index2">
      <h2>答主是谁</h2>
      <div class="line"></div>
      <div class="benner"></div>
      <ul>
        <li class="l1">
          <p>
            在校大学生
          </p>
        </li>
        <li class="l2">
          <div class="l2_cont">
            <h3>职场小生</h3>
            <p>1.善于利用互联网搜索想要的答案，噼里啪啦键盘侠。</p>
            <p>2.有精力、有活力，愿意和一群小伙伴儿一起参与网上发布的各种有趣活动。</p>
          </div>
        </li>
        <li class="l3">
          <p>旅行爱好者</p>
        </li>
      </ul>
    </div>
    <div class="index3">
      <h2>答主收益及义务</h2>
      <div class="line"></div>
      <ul>
        <li class="l1">
          <span></span>
          <h3>答主收益</h3>
          <p>1.通过答题赚到实实在在的现金钞票~,支持随时提现。</p>
          <p>2.在回答各种旅游问题的同时，学习很多的相关知识,赚钱学习两不误。</p>
          <p>3.帮助更多爱好旅行的人,让更多的人认识你~</p>
        </li>
        <li class="l2">
          <span></span>
          <h3>答主义务</h3>
          <p>1.认真回答每一个问题。</p>
          <p>2.回答更多平台的问题~</p>
        </li>
      </ul>
    </div>
    <div class="index4">
      <h2>我该如何做</h2>
      <div class="line4"></div>
      <ul>
        <li>
          <div class="cent4">
            <span class="sp1"></span>
            <p>免费注册并登录问答账号</p>
          </div>
          <span class="sp"></span>
        </li>
        <li>
          <div class="cent4">
            <span class="sp2"></span>
            <p>点击"立即答题"获取问题</p>
          </div>
          <span class="sp"></span>
        </li>
        <li>
          <div class="cent4">
            <span class="sp3"></span>
            <p>拿到问题后，认真回答问题。</p>
            <p>答案可依据自己的旅行经验,或者旅游网站、搜索引擎进行获取</p>
          </div>
          <span class="sp"></span>
        </li>
        <li>
          <div class="cent4">
            <span class="sp4"></span>
            <p>提交自己的回答,等待平台审核。</p>
            <p>问题可以点击"下一题"进行持续作答，实在找不到答案的可以跳过~</p>
          </div>
          <span class="sp"></span>
        </li>
        <li>
          <div class="cent4">
            <span class="sp5"></span>
            <p>审核通过，获得收益。手可随时提现</p>
          </div>
          <span class="sp"></span>
        </li>
      </ul>
      <button class="btn2" @click="myQuen">立即答题</button>
    </div>

  </div>
</template>
<script>
import IndexService from '../api/indexServer'

export default {
  data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  methods: {
    myQuen() {
      IndexService.nickname('chen')
        .then((res) => {
          console.log(res)
        })
      this.$router.push({ path: '/question' })
    }
  }
}
</script>
