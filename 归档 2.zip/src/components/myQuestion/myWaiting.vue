<template>
  <el-main>
    <div class='waitCheck'>
      <div class='a_lists'>
        <h1 class='q_title textBig' @click='isShow' v-show='show_a'>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念<span
          class='q_static'>待审核</span><i class='el-icon-minus up'></i></h1>
        <h1 class='q_title overHiden' @click='isShow' v-show='!show_a'>
          与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念遵循用户习惯的语言和概念遵循用户习惯的语言和概念<i class='el-icon-plus down'></i></h1>
        <el-collapse-transition>
          <div v-show='show_a'>
            <p class='a_descript'>
              在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</p>
            <div class='income'>悬赏积分<em class=gold></em><a class=goldNum>108</a>
              <div class='source'>来源：百度知道<span>|</span>2017-11-30</div>
            </div>
            <div class='myAnswer'>
              <h2 class='a_top'><i class='lamp'></i>我的回答<span class='a_times'>2017-11-30 12:20:45</span></h2>
              <div :class="isTogel ? 'a_content' : 'a_content hideSome' ">
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
              </div>
              <el-button type="text" @click='detailTogel'>{{buttonText}}</el-button>
            </div>
          </div>
        </el-collapse-transition>
      </div>
      <!--<div class='a_lists'>
        <h1 class='q_title textBig' @click='isShow' v-show='show_a'>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念<span
          class='q_static'>待审核</span><i class='el-icon-minus up'></i></h1>
        <h1 class='q_title overHiden' @click='isShow' v-show='!show_a'>
          与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念遵循用户习惯的语言和概念遵循用户习惯的语言和概念<i class='el-icon-plus down'></i></h1>
        <el-collapse-transition>
          <div v-show='show_a'>
            <p class='a_descript'>
              在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</p>
            <div class='income'>悬赏积分<em class=gold></em><a class=goldNum>108</a>
              <div class='source'>来源：百度知道<span>|</span>2017-11-30</div>
            </div>
            <div class='myAnswer'>
              <h2 class='a_top'><i class='lamp'></i>我的回答<span class='a_times'>2017-11-30 12:20:45</span></h2>
              <div :class="isTogel ? 'a_content' : 'a_content hideSome' ">
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
              </div>
              <el-button type="text" @click='detailTogel'>{{buttonText}}</el-button>
            </div>
          </div>
        </el-collapse-transition>
      </div>
      <div class='a_lists'>
        <h1 class='q_title textBig' @click='isShow' v-show='show_a'>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念<span
          class='q_static'>待审核</span><i class='el-icon-minus up'></i></h1>
        <h1 class='q_title overHiden' @click='isShow' v-show='!show_a'>
          与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念遵循用户习惯的语言和概念遵循用户习惯的语言和概念<i class='el-icon-plus down'></i></h1>
        <el-collapse-transition>
          <div v-show='show_a'>
            <p class='a_descript'>
              在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</p>
            <div class='income'>悬赏积分<em class=gold></em><a class=goldNum>108</a>
              <div class='source'>来源：百度知道<span>|</span>2017-11-30</div>
            </div>
            <div class='myAnswer'>
              <h2 class='a_top'><i class='lamp'></i>我的回答<span class='a_times'>2017-11-30 12:20:45</span></h2>
              <div :class="isTogel ? 'a_content' : 'a_content hideSome' ">
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
              </div>
              <el-button type="text" @click='detailTogel'>{{buttonText}}</el-button>
            </div>
          </div>
        </el-collapse-transition>
      </div>-->
    </div>
    <!--分页-->
    <div class="block">
      <el-pagination layout="prev, pager, next" :total='total' :page-size='page'></el-pagination>
    </div>
  </el-main>
</template>

<script>
  export default {
    data () {
      return {
        myHeader: {
          myTotalA: '123456',
          myWaiting: '10',
          passingRate: '78.8%',
          myGet: '3553'
        },
        static: {
          staWaiting: '21',
          staPassing: '32',
          staFailing: '99+'
        },
        total: 200,
        page: 20,
        activeNames: ['1'],
        buttonText: '显示全文',
        showIndex: 0,
        show_a: false,
        isTogel: false
      }
    },
    mounted () {
      // 初始化
    },
    methods: {
      // 显示隐藏按钮
      isShow (n) {
        this.show_a = !this.show_a
      },
      detailTogel () {
        if (this.isTogel === true) {
          this.buttonText = '显示全文'
        } else if (this.isTogel === false) {
          this.buttonText = '收起'
        }
        this.isTogel = !this.isTogel
      },
      onSubmit () {
        // 提交
        // this.$refs.infoForm.validate，这是表单验证
        this.$refs.infoForm.validate((valid) => {
          if (valid) {
            this.$post('m/add/about/us', this.infoForm).then(res => {
              if (res.errCode === 200) {
                this.$message({
                  message: res.errMsg,
                  type: 'success'
                })
                this.$router.push('/aboutus/aboutlist')
              } else {
                this.$message({
                  message: res.errMsg,
                  type: 'error'
                })
              }
            })
          }
        })
      }
    },
    components: {}
  }
</script>
<style scoped lang="stylus" rel="stylesheet/stylus"></style>
