<template>
  <div class="register">
    <div class="container">
      <div class="title">创建账号</div>            
      <div class="main">
        <div class="phone">
          <label>输入你的手机号:</label>
          <input type="text" class="phoneNum" v-model="baseData.mobile" @blur="validate('phone')">
          <div class="warn">
            <p v-show="validateInput.phoneNull">请输入手机号</p>            
            <p v-show="validateInput.phoneWrong">你输入的手机号不合法，请输入正确11位手机号</p>            
          </div>
        </div>
        <div class="check">
          <label>输入验证码:</label>
          <input type="text" class="checkNum" v-model="baseData.validateCode">
          <button>获取验证码</button>
          <button v-show="false">12s</button>
          <div class="warn">
            <p>你输入的验证码有误，请重新输入</p>            
          </div>
        </div>
        <div class="password">
          <label>设置密码:</label>
          <input type="text" @blur="validate('password')" class="passwordNum" placeholder="长度6-14个字符；不支持空格" v-model="baseData.password">
          <div class="warn">
            <p v-show="validateInput.passwordWrong">你输入的密码格式不合法，请按要求设置</p>            
          </div>
        </div>
        <div class="creat">
          <button type="button" class="created">创建账号</button>
        </div>
        <div class="toLogin">
          <span>已有账号？</span>
          <router-link to="/login" class="link">登录</router-link>
        </div>
        <div class="toAgreement">
          <span>注册即表示您同意网站的</span>
          <router-link to="/agreement" class="link">用户协议</router-link>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  data () {
    return {
      // 参数
      baseData: {
        mobile: '',
        validateCode: '',
        password: ''
      },
      // input验证
      validateInput: {
        phoneNull: false, // 手机号为空
        phoneWrong: false, // 手机号不合法
        passwordWrong: false // 密码不合法
      }
    }
  },
  methods: {
    // 验证
    validate (info) {
      var _this = this
      if (info === 'phone') {
          // 验证手机号
        if (this.baseData.mobile.length === 0) {
          this.validateInput.phoneNull = true
          this.validateInput.phoneWrong = false
          return
        } else if (/^1[3|4|5|7|8][0-9]\d{8}$/.test(_this.baseData.mobile)) {
          this.validateInput.phoneNull = false
          this.validateInput.phoneWrong = false
          return
        } else {
          this.validateInput.phoneNull = false
          this.validateInput.phoneWrong = true
          return
        }
      }
      if (info === 'password') {
        // 验证密码
        if (this.baseData.password.indexOf(' ') !== -1 || this.baseData.password.length < 6 || this.baseData.password.length > 14) {
          this.validateInput.passwordWrong = true
        } else {
          this.validateInput.passwordWrong = false
        }
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="stylus" rel="stylesheet/stylus">
.container {
  // height: 550px;
  width: 623px;
  box-shadow: 0px 0px 10px #D6D6D6;
  margin: 89px auto 180px;
  background-color #fff
  color: rgb(1, 0, 25);
  font-family 'PingFangSC-Regular'
  .title {
    height 75px
    line-height 75px
    font-size: 24px;
    color #ffffff
    text-align center
    background-color rgb(192,192,192)
  }
  .main {
    // width: 100%;
    display flex
    align-items flex-end
    flex-direction column
    margin-right 108px
    label {
      font-size 18px
      margin-right 20px
    }

    p {
      background: url('./note.png') no-repeat left;
      background-size: auto 100%;
      padding-left: 20px;
      color: #f9553f;
      font-size 12px
    }
    .warn{
      height 25px
      font-size 12px
      color rgb(249,85,63)
      padding-top 5px
      box-sizing border-box
    }

    input {
      width: 302px;
      height: 46px;
      border: 1px solid #C0C0C0;
      outline: none;
      box-sizing: border-box;
      padding-left 8px
    }
    input::-webkit-input-placeholder, textarea::-webkit-input-placeholder { 
      font-size 14px
    } 
    input:-moz-placeholder, textarea:-moz-placeholder { 
      font-size 14px
    } 
    input::-moz-placeholder, textarea::-moz-placeholder { 
      font-size 14px
    } 
    input:-ms-input-placeholder, textarea:-ms-input-placeholder { 
      font-size 14px
    } 
    button{
      height 46px
      font-size 18px
      color #ffffff
      font-family 'AdobeHeitiStd-Regular'
      background-color rgb(249,85,63)      
    }
    // 手机号
    .phone{
      margin-top 54px
      .warn{
        height 25px
        padding-left 156px
      }
    }
    // 验证码
    .check {
      input {
        width 165px
      }
      .warn{
        height 25px
        padding-left 120px
      }
      button {
        height 46px
        width 132px
        outline none 
        border none
      }
    }
    // 设置密码
    .password{
      .warn{
        padding-left 102px        
      }
    }
    // 创建账号
    .creat {
      button{
        width 408px
        outline none 
        border none
        margin 0 0 25px 0
      }
    }
    .toLogin{
      align-self flex-start
      margin-left 106px
      font-size 12px
      color rgb(0,1,32)
      .link{
        color rgb(249,85,63)
      }
    }
    .toAgreement{
      margin-bottom 50px
      margin-top -17px
      font-size 12px
      color rgb(148,148,148)
      .link{
        color rgb(249,85,63)
      }
    }    
  }
}
</style>
