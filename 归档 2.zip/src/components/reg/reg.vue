<template>
 <div>注册</div>
</template>

 <script type="text/ecmascript-6">

export default {

}
</script>
<style scoped lang="stylus" rel="stylesheet/stylus">
</style>

