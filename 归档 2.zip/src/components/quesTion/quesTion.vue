<style scoped lang="stylus" rel="stylesheet/stylus">
.myQ {
  margin: 42px 15%;
  display: flex;

  .left {
    // width: 100px;
    height: 100%;
    display: flex;
    font-size: 24px;
    color: #e7331b;
    flex-direction: row;

    .left_cont {
      display: flex;

      span {
        display: block;
        width: 37px;
        height: 27px;
        background: url('./jb.png') no-repeat;
        background-size: 100%;
      }

      p {
        margin: 0 30px 0 5px;
      }
    }
  }

  .content {
    color: #000120;

    h2 {
      font-size: 26px;
      margin-bottom: 28px;
    }

    p {
      font-size: 18px;
      line-height: 30px;
    }

    .but {
      display: flex;
      font-size: 14px;
      color: #adadad;

      p {
        font-size: 14px;
        margin: 0 12px 24px 0;
      }
    }
  }

  .info {
    border-radius: 10px;
    line-height: 20px;
    padding: 10px;
    margin: 10px;
    background-color: #ffffff;
  }

  .bad {
    width: 988px;
    padding: 28px;
    background-color: #fff1f1;
    margin: 30px 0;

    .bad_t {
      display: flex;

      span {
        display: block;
        width: 23px;
        height: 23px;
        background: url('./x.png') no-repeat;
        background-size: 100%;
      }

      h2 {
        font-size: 20px;
        color: #e7331b;
        margin-left: 10px;
      }
    }

    .btn3 {
      text-align: center;
      display: flex;
      margin: 0 auto;
      color: #adadad;
    }

    .a_content {
      font-size: 18px;
      line-height: 30px;
    }

    .hideSome {
      word-break: break-all;
      display: -webkit-box;
      -webkit-line-clamp: 5;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  }

  .ck {
    width: 988px;
    padding: 28px;
    background-color: #e9e9e9;
    margin: 30px 0;

    .ck_t {
      display: flex;

      span {
        display: block;
        width: 21px;
        height: 25px;
        background: url('./da.png') no-repeat;
        background-size: 100%;
      }

      h2 {
        font-size: 20px;
        color: #000120;
        margin-left: 10px;
      }
    }

    .btn3 {
      text-align: center;
      display: flex;
      margin: 0 auto;
      color: #adadad;
    }

    .a_content {
      font-size: 18px;
      line-height: 30px;
    }

    .hideSome {
      word-break: break-all;
      display: -webkit-box;
      -webkit-line-clamp: 5;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  }

  .right {
    display: flex;

    span {
      width: 58px;
      height: 58px;
      display: block;
      background: url('./wxz.png') no-repeat;
      background-size: 100%;
    }
  }
}
</style>

<template>
  <div class="myQ">
    <div class="left">
      <div class="left_cont">
        <span></span>
        <p>108</p>
      </div>
    </div>
    <div class="content">
        <h2>问题:2017请问中国人去日本九州现在是不是有免签证30天的邀请函怎么开？</h2>
        <p>描述:今年冬季准备去日本玩，但是很多问题还不知道，能问问大家可以问问吗？在日本已通过购物点先进退税，回国前在机场还需要排队今年冬季准备去日本玩儿，但是很多问题还不知道，能问问大家可以吗？在日本已通过购物点现金退税购物先进退税，回国前在机场还需要排...</p>
        <div class="but">
          <p>来源:百度知道</p>
          <p>|</p>
          <p>2017-11-30</p>
        </div>
        <div class="fwb">
          <div class="components-container">
            <button @click="getUEContent">获取内容</button>
            <div class="editor-container">
              <UE :defaultMsg=defaultMsg :config=config :id=ue1 ref="ue"></UE>
            </div>
        </div>
         <button class="btn1">不会</button>
         <button class="btn2">提交回答</button>
        </div>
      <div class="bad">
        <div class="bad_t">
          <span></span>
          <h2>错误回答</h2>
        </div>
        <div :class="isTogel ? 'a_content' : 'a_content hideSome' ">
              控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
              控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
              控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
              页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
         </div>
         <el-button type="text" @click='detailTogel' class="btn3">{{buttonText}}</el-button>
      </div>
      <div class="ck">
        <div class="ck_t">
          <span></span>
          <h2>参考回答</h2>
        </div>
        <div :class="isTogel2 ? 'a_content' : 'a_content hideSome' ">
                  控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                  控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
                  控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。控制反馈：通过界面样式和交互动效让用户可以清晰的感知自己的操作；
                  页面反馈：操作后，通过页面元素的变化清晰地展现当前状态。
            </div>
         <el-button type="text" @click='detailTogel2' class="btn3">{{buttonText2}}</el-button>
      </div>
    </div>
    <div class="right"></div>
    <span></span>
  </div>
</template>

<script type="text/ecmascript-6">
import UE from '../../components/ue/ue.vue';
export default {
  components: { UE },
  data() {
    return {
      defaultMsg: '这里是UE测试',
      config: {
        initiaFrameWidth: null,
        initiaFrameHeight: 350
      },
      isTogel: false,
      isTogel2: false,
      buttonText: '显示全文',
      buttonText2: '显示全文',
      ue1: "ue1"
    }
  },
  computed: {
    // editor() {
    //   return this.$refs.myQuillEditor.quill
    // }
  },
  mounted() {
    // 初始化
  },
  methods: {
    getUEContent() {
      let content = this.$refs.ue.getUEContent(); // 调用子组件方法
      this.$notify({
        title: '获取成功，可在控制台查看！',
        message: content,
        type: 'success'
      });
      console.log(content)
    },
    // 显示隐藏按钮
    isShow(n) {
      this.show_a = !this.show_a
    },
    detailTogel() {
      if (this.isTogel === true) {
        this.buttonText = '显示全文'
      } else if (this.isTogel === false) {
        this.buttonText = '收起'
      }
      this.isTogel = !this.isTogel
    },
    detailTogel2() {
      if (this.isTogel2 === true) {
        this.buttonText2 = '显示全文'
      } else if (this.isTogel2 === false) {
        this.buttonText2 = '收起'
      }
      this.isTogel2 = !this.isTogel2
    },
    onSubmit() {
      // 提交
      // this.$refs.infoForm.validate，这是表单验证
      this.$refs.infoForm.validate((valid) => {
        if (valid) {
          this.$post('m/add/about/us', this.infoForm).then(res => {
            if (res.errCode === 200) {
              this.$message({
                message: res.errMsg,
                type: 'success'
              })
              this.$router.push('/aboutus/aboutlist')
            } else {
              this.$message({
                message: res.errMsg,
                type: 'error'
              })
            }
          })
        }
      })
    }
  },
}
</script>

